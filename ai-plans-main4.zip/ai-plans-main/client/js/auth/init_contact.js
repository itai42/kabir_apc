import ui from '../ui.js?v=146'

console.log('contact')